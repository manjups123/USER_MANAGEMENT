from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import UserSignupForm
from .models import UserProfile

def signup(request):
    if request.method == 'POST':
        form = UserSignupForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserSignupForm()
    return render(request, 'signup.html', {'form': form})

def dashboard(request):
    user = request.user
    if user.user_type == 'Patient':
        return render(request, 'patient_dashboard.html', {'user': user})
    elif user.user_type == 'Doctor':
        return render(request, 'doctor_dashboard.html', {'user': user})
    return redirect('login')



def home(request):
    return render(request, 'home.html')
